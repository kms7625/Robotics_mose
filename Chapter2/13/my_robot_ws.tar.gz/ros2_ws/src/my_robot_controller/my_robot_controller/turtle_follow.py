import random                              # 임의 위치를 위한 표준 라이브러리
import rclpy
import math
from rclpy.node import Node
from turtlesim.srv import Spawn
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from std_srvs.srv import Empty
from turtlesim.srv import Kill



class TurtleFollow(Node):
    def __init__(self):
        super().__init__('turtle_follow')
        self.spawn_client = self.create_client(Spawn, '/spawn')   # ① 자료형

        req = Spawn.Request()
        req.x = random.uniform(1.0, 10.0)      # 1~10 사이 임의 실수 (벽에서 안전한 범위)
        req.y = random.uniform(1.0, 10.0)
        req.theta = random.uniform(0.0, 6.28)  # 임의 방향 (0~2π 라디안)
        req.name = 'turtle2'
        future = self.spawn_client.call_async(req)              # ② 비동기 호출 메서드
        future.add_done_callback(self.spawn_done)                      # ③ 완료 시 콜백 예약
        self.pose1 = None                          # ← 추가
        self.pose2 = None                          # ← 추가
        self.create_subscription(Pose, '/turtle1/pose', self.pose1_callback, 10)   # ← 추가
        self.create_subscription(Pose, '/turtle2/pose', self.pose2_callback, 10)   # ← 추가
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)      # ← 추가

        self.kill_client = self.create_client(Kill, '/kill')      # /kill 클라이언트
        self.create_service(Empty, '/quit', self.quit_callback)   # /quit 서버
        self.finished = False                                      # 판정 플래그


    def spawn_done(self, future):
        result = future.result()               # 응답 객체 꺼내기
        self.get_logger().info(f'거북이 생성됨: {result.name}')   # 응답의 name 필드 사용
    def pose1_callback(self, msg):
        self.pose1 = msg
        self.follow()                  # 내 위치가 갱신될 때마다 추적 판단

    def pose2_callback(self, msg):
        self.pose2 = msg

    def follow(self):
        if self.finished:
            return                   # 종료 절차 중이면 아무것도 안 함
        if self.pose1 is None or self.pose2 is None:
            return

        dx = self.pose2.x - self.pose1.x
        dy = self.pose2.y - self.pose1.y
        target_angle = math.atan2(dy, dx)          # 목표 방향각

        dx = self.pose2.x - self.pose1.x
        dy = self.pose2.y - self.pose1.y
        distance = math.sqrt(dx**2 + dy**2)        # 두 거북이 사이 거리

        if distance < 0.5:                          # 만남 판정 (0.5칸 이내)
            self.finished = True
            self.get_logger().info('만났다! 이동 로봇 제거 후 종료')
            req = Kill.Request()
            req.name = 'turtle1'                    # 이동 중인 로봇을 지운다 (지시서 4번)
            future = self.kill_client.call_async(req)
            future.add_done_callback(self.last_kill_done)
            return


        error = target_angle - self.pose1.theta    # 방향 오차
        while error > math.pi:                     # 오차를 -π ~ +π 범위로 보정
            error -= 2 * math.pi
        while error < -math.pi:
            error += 2 * math.pi

        cmd = Twist()
        cmd.linear.x = 1.5             # 일정 속도 전진
        cmd.angular.z = 3.0 * error    # P 제어: 오차에 비례해 회전
        self.publisher.publish(cmd)

    def last_kill_done(self, future):
        raise SystemExit                            # 마지막 kill 완료 → 종료

    def quit_callback(self, request, response):
        self.finished = True                        # 추적 중지
        self.get_logger().info('quit 요청: 두 로봇 모두 제거')
        req = Kill.Request()
        req.name = 'turtle1'
        future = self.kill_client.call_async(req)
        future.add_done_callback(self.quit_kill1_done)
        return response

    def quit_kill1_done(self, future):
        req = Kill.Request()
        req.name = 'turtle2'                        # turtle1 다음 turtle2 제거
        future = self.kill_client.call_async(req)
        future.add_done_callback(self.last_kill_done)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleFollow()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
