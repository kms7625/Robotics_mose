from launch import LaunchDescription      # 런치 설계도 클래스
from launch_ros.actions import Node       # "노드를 실행하라"는 액션


def generate_launch_description():        # ros2 launch가 찾는 약속된 함수 이름
    return LaunchDescription([
        Node(
            package='turtlesim',               # 패키지 이름
            executable='turtlesim_node',       # 실행 이름
        ),
        Node(
            package='my_robot_controller',
            executable='turtle_follow',
        ),
    ])
