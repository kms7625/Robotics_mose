import rclpy
from rclpy.node import Node

class logging_node(Node):
	def __init__(self):
		super().__init__('logging_node')
		# log
		self.get_logger().info(self.get_name())

def main(args=None):
    rclpy.init(args=args)
    node = logging_node()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
   main()
