import rclpy
from rclpy.node import Node

class timer_node(Node):
  def __init__(self):
    super().__init__('timer_node')
    self.timer2 = self.create_timer(2.0, self.timer2_callback)
    self.timer3 = self.create_timer(3.0, self.timer3_callback)
    self.counter = 0

  def timer2_callback(self):
    self.counter = self.counter+1
    self.get_logger().info(f"2 seconds passed : {self.counter}")

  def timer3_callback(self):
    self.counter = self.counter-1
    self.get_logger().info(f"3 seconds passed : {self.counter}")

def main(args=None):
    rclpy.init(args=args)
    node = timer_node()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
