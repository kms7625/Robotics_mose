import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist        # (1) 속도 명령 메시지 클래스 (문제8에서 썼던 것)


class TurtleMoveControl(Node):
    def __init__(self):
        super().__init__('turtle_move_control')
        self.margin = 2.0
        self.wall = 11.09
        self.subscription = self.create_subscription(
            Pose, '/turtle1/pose', self.pose_callback, 10)      # (2) 구독 메시지 클래스
        self.publisher = self.create_publisher(
            Twist, '/turtle1/cmd_vel', 10)                                   # (3) 발행할 토픽 이름

    def pose_callback(self, msg):
        cmd = Twist()
        if msg.x < self.margin or msg.x > self.wall - self.margin or \
           msg.y < self.margin or msg.y > self.wall - self.margin:   # (4) 남은 벽 하나
            cmd.linear.x = 1.0      # 위험: 천천히 전진하며
            cmd.angular.z = 1.5     #       왼쪽으로 곡선 회전
        else:
            cmd.linear.x = 2.0      # 안전: 직진
            cmd.angular.z = 0.0
        self.publisher.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = TurtleMoveControl()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
