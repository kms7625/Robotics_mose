import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose


class TurtlePoseNode(Node):
    def __init__(self):
        super().__init__('turtle_pose')
        self.last_pose = None
        self.subscription = self.create_subscription(
            Pose, '/turtle1/pose', self.pose_callback, 10)

    def pose_callback(self, msg):
        if self.last_pose is None or \
           msg.x != self.last_pose.x or \
           msg.y != self.last_pose.y or \
           msg.theta != self.last_pose.theta:
            self.get_logger().info(
                f'x={msg.x:.3f}, y={msg.y:.3f}, theta={msg.theta:.3f}')
        self.last_pose = msg


def main(args=None):
    rclpy.init(args=args)
    node = TurtlePoseNode()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
