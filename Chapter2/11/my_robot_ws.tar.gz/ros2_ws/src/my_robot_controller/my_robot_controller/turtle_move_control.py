import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist        # (1) 속도 명령 메시지 클래스 (문제8에서 썼던 것)
from std_srvs.srv import Empty
from turtlesim.srv import Kill


class TurtleMoveControl(Node):
    def __init__(self):
        super().__init__('turtle_move_control')
        self.margin = 2.0
        self.wall = 11.09
        self.subscription = self.create_subscription(
            Pose, '/turtle1/pose', self.pose_callback, 10)      # (2) 구독 메시지 클래스
        self.publisher = self.create_publisher(
            Twist, '/turtle1/cmd_vel', 10)                                   # (3) 발행할 토픽 이름
        self.create_service(Empty, '/quit', self.quit_callback)    # 추가: 서비스 서버
        self.kill_client = self.create_client(Kill, '/kill')    # 클라이언트 생성

    def pose_callback(self, msg):
        cmd = Twist()
        if msg.x < self.margin or msg.x > self.wall - self.margin or \
           msg.y < self.margin or msg.y > self.wall - self.margin:   # (4) 남은 벽 하나
            cmd.linear.x = 1.0      # 위험: 천천히 전진하며
            cmd.angular.z = 1.5     #       왼쪽으로 곡선 회전
        else:
            cmd.linear.x = 2.0      # 안전: 직진
            cmd.angular.z = 0.0
        self.publisher.publish(cmd)

    def quit_callback(self, request, response):
        self.get_logger().info('quit 요청 받음!')  # 터미널에 로그 출력
        req = Kill.Request()                       # 요청 객체 생성
        req.name = 'turtle1'                       # string name 필드 채우기
        future   = self.kill_client.call_async(req) # 비동기 호출: 보내놓고 즉시 리턴
        future.add_done_callback(self.kill_done)   # 응답 도착 시 kill_done 호출 예약
        return response                            # /quit 응답은 바로 돌려줌

    def kill_done(self, future):
        self.get_logger().info('거북이 제거 완료, 종료합니다')
        raise SystemExit                              # spin을 빠져나가는 신호

def main(args=None):
    rclpy.init(args=args)
    node = TurtleMoveControl()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
      pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
