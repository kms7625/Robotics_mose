import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist

class circle_turtle(Node):
  def __init__(self):
    super().__init__('circle_turtle')
    self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
    self.timer     = self.create_timer(0.01, self.timer_callback)

  def timer_callback(self):
    msg = Twist()
    msg.linear.x  = 2.0
    msg.angular.z = 2.0
    self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = circle_turtle()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
