import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class MyJointStatePublisher(Node):
    def __init__(self):
        super().__init__('my_joint_state_publisher')
        self.publisher = self.create_publisher(JointState, 'joint_states', 10)
        self.timer = self.create_timer(0.05, self.publish_joint_states)
        self.angle = 0.0

    def publish_joint_states(self):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = ['left_wheel_joint', 'right_wheel_joint']
        msg.position = [self.angle, self.angle]
        self.angle += 0.1
        if self.angle > 2 * math.pi:
            self.angle -= 2 * math.pi
        self.publisher.publish(msg)


def main():
    rclpy.init()
    node = MyJointStatePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()